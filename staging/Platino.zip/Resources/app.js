(function() {
    var Window = require('ApplicationWindow');
    new Window().open({fullscreen:true, navBarHidden:true, exitOnClose:true});
})();