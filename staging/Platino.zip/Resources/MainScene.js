var platino = require('co.lanica.platino');

var MainScene = function(window, game) {
	var scene = platino.createScene();

	var onSceneActivated = function(e) {

		// ---- create sprites, add listeners, etc. ----

		Ti.API.info("MainScene has been activated.");

	};

	var onSceneDeactivated = function(e) {

		// ---- remove sprites, listeners, etc. ----

		Ti.API.info("MainScene has been deactivated.");

	};

	scene.addEventListener('activated', onSceneActivated);
	scene.addEventListener('deactivated', onSceneDeactivated);
	return scene;
};

module.exports = MainScene;